 --This SQL query returns call records and applys logic to assist with call accounting--
-------------------------------------------------------------------------------------------
use LcsCDR

SELECT
--CALL START TIME:
m.StartTime as 'StartTime(UTC)',
CONVERT(datetime, SWITCHOFFSET(CONVERT(datetimeoffset, m.StartTime), DATENAME(TzOffset, SYSDATETIMEOFFSET()))) as 'StartTime(Local)',

--CALL END TIME:
--m.EndTime as 'EndTime(UTC)',
--CONVERT(datetime, SWITCHOFFSET(CONVERT(datetimeoffset, m.StartTime), DATENAME(TzOffset, SYSDATETIMEOFFSET()))) as 'EndTime(Local)',

--FROM DETAILS:
fp.PhoneUri as 'From Number',
fu.UserUri as 'From Uri',
--fcv.Version AS 'FromClientVersion',

CASE
	--Lookup From Number region in rate card
	WHEN fp.PhoneUri IS NOT NULL THEN (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE fp.PhoneUri LIKE '+' + Destination + '%' OR fp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
END AS 'FromRegion',

--REFERRER DETAILS:
CASE
	--Lookup ReferredByNumber in users table
	WHEN ru.UserUri IS NOT NULL THEN (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri LIKE SipAddress)
END AS 'ReferredByNumber',

ru.UserUri as 'ReferredByUri',

CASE
	--Lookup ReferredByNumber in users table then lookup region in rate card 
	WHEN ru.UserUri IS NOT NULL THEN (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard  
	WHERE (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE '+' + Destination + '%' 
	OR (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE Destination + '%' ORDER BY Destination desc)
END AS 'ReferredByNumberRegion',

--TO DETAILS:
cp.PhoneUri as 'To Number',
tu.UserUri  as 'To Uri',
--tcv.Version AS 'ToClientVersion',

CASE
WHEN cp.PhoneUri IS NOT NULL THEN (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
END AS 'ToRegion',

--CALL ROUTE DETAILS:
fgw.Gateway as 'From Gateway',
fms.MediationServer as 'From Mediation Server',
tgw.Gateway as 'To Gateway',
tms.MediationServer as 'To Mediation Server',

--CALL DIRECTION:
CASE
	WHEN fgw.Gateway IS NULL AND tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN 'Outbound - PSTN' --IF FROM Gateway is NULL and TO gateway contains a PSTN gateways, assume call is outbound to PSTN
	WHEN fgw.Gateway IS NULL AND tgw.Gateway NOT IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN 'Outbound - Unknown G/W' --IF FROM Gateway is NULL and TO Gateway does NOT contain a known PSTN gateway, record as outbound via unknown PSTN gateway
	WHEN tgw.Gateway IS NULL AND fgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN 'Inbound - PSTN' --IF TO Gateway is NULL and FROM gateway contains a PSTN gateway, assume call is inbound from PSTN
	WHEN tgw.Gateway IS NULL AND fgw.Gateway NOT IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN 'Inbound - Unknown G/W' --IF TO Gateway is NULL and FROM Gateway does NOT contain a known PSTN gateway, record as inbound via unknown PSTN gateway
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NOT NULL THEN 'FWD Outbound - PSTN' --IF TO Gateway contains a known PSTN gateway AND RefferedBy is NOT NULL then assume the call was forwarded outbound to PSTN
	WHEN tgw.Gateway NOT IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NOT NULL THEN 'FWD Outbound - Unknown G/W' --IF TO Gateway does NOT contain a known Gateway AND AND RefferedBy is NOT NULL then assume the call was forwarded outbound via an unknown PSTN gateway
	WHEN tgw.Gateway IS NULL AND fgw.Gateway IS NULL THEN 'Lync to Lync' --IF TO Gateway is NULL and FROM gateway is NULL, assume call is Lync to Lync
END AS CallDirection,

--CHARGE TO:
CASE
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NOT NULL THEN ru.UserUri --IF TO Gateway contains a PSTN gateway AND Referred-By is NOT NULL then charge to referrer
	WHEN fgw.Gateway IS NULL AND tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN fu.UserUri --If TO gateway contains a PSTN gateway AND Referred-By is NULL, charge to users URI
END AS ChargeTo,

--CALL DURATION:
CASE
	--Ensure that the call start time is less than the call end time to avoid huge durations. A tiny amount of data in Lync is out by a few milliseconds creating durations of nearly 24hours.
	WHEN m.EndTime >= m.StartTime THEN (CONVERT(varchar(50), m.EndTime - m.StartTime,108)) 
	--WHEN m.EndTime >= m.StartTime THEN DateDiff(millisecond, m.StartTime, m.EndTime)
	WHEN m.EndTime < m.StartTime THEN 'error:start>end'
END AS 'Duration',

--CALL RATE:
CASE
	--If the referrer initiates an outbound call to the PSTN and is in the came calling area as the called number then apply the local calling rate
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NOT NULL
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard  
	WHERE (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE ('+' + Destination + '%')
	OR (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	THEN 'PSvar_RateLocalCallingArea'
	--THEN '0.02'
	--If the caller initiates an outbound call to the PSTN and is in the came calling area as the called number then apply the local calling rate	
	WHEN fgw.Gateway IS NULL AND tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NULL
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE fp.PhoneUri LIKE '+' + Destination + '%' OR fp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	THEN 'PSvar_RateLocalCallingArea'
	--THEN '0.02'
	--If the caller and called parties are not in the same calling area then look up the rate for the destination
	--WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN (SELECT TOP 1 Rate FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	--ADDED BELOW 2 lines and commented out 1 above
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) 
	THEN CAST((SELECT TOP 1 Rate FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc) as decimal(20,2))
END AS Rate,

--CALCULATE CALL COST:
CASE
	--If the referrer initiates a local area call under 60 seconds then multiply the local calling rate by 1
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND ru.UserUri IS NOT NULL AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 <= 60) 
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE ('+' + Destination + '%')
	OR (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	--THEN 1 * 100
	THEN 1 * 'PSvar_RateLocalCallingArea'
	
	--If the caller initiates a local area call under 60 seconds then multiply the local calling rate by 1
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND ru.UserUri IS NULL AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 <= 60) 
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE fp.PhoneUri LIKE '+' + Destination + '%' OR fp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	--THEN 1 * 200
	THEN 1 * 'PSvar_RateLocalCallingArea' --ADDED 1 *
	
	--If the referrer initiates a local area call over 60 seconds then divide total seconds by 60 then multiple the local calling rate
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND ru.UserUri IS NOT NULL AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 > 60) 
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE ('+' + Destination + '%')
	OR (SELECT TOP 1 DDI FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri = SipAddress) LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	--THEN ((CAST((DateDiff(millisecond, m.StartTime, m.EndTime))as decimal)/1000)/60) * 0.02
	THEN ((CAST((DateDiff(millisecond, m.StartTime, m.EndTime))as decimal)/1000)/60) * 'PSvar_RateLocalCallingArea'
	
	--If the caller initiates a local area call over 60 seconds then divide total seconds by 60 then multiple the local calling rate
		--If the caller initiates a local area call under 60 seconds then multiply the local calling rate by 1
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND ru.UserUri IS NULL AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 > 60) 
	AND (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE fp.PhoneUri LIKE '+' + Destination + '%' OR fp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	= (SELECT TOP 1 CallingArea FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc)
	--THEN ((CAST((DateDiff(millisecond, m.StartTime, m.EndTime))as decimal)/1000)/60) * 0.02
	THEN ((CAST((DateDiff(millisecond, m.StartTime, m.EndTime))as decimal)/1000)/60) * 'PSvar_RateLocalCallingArea'
	
	--If the call is less than 60 seconds then multiple the found rate by 1
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 <= 60) THEN 1 * CAST((SELECT TOP 1 Rate FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc) as decimal(20,2))
	--If the call is over 60 seconds then divide total seconds by 60 and multiple by the found rate
	WHEN (tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)) AND (DateDiff(millisecond, m.StartTime, m.EndTime)/1000 > 60) THEN CAST((DateDiff(millisecond, m.StartTime, m.EndTime)/1000)as decimal)/60 * CAST((SELECT TOP 1 Rate FROM tempdb.dbo.LyncCallAccountingRateCard WHERE cp.PhoneUri LIKE '+' + Destination + '%' OR cp.PhoneUri LIKE Destination + '%' ORDER BY Destination desc) as decimal(20,2))
	--Produce an error if the start time is greater than the end time. This will avoid large call costs when this is clearly an error
	WHEN m.EndTime < m.StartTime THEN 'error:start>end'
END AS 'CallCharge',

--COMPANY TO CHARGE:
CASE
	--If the referrer initiates an outbound PSTN call then lookup the ReferredByURI for company details
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) AND ru.UserUri IS NOT NULL THEN (SELECT TOP 1 Company FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri LIKE SipAddress)
	--If the caller initiates an outbound PSTN call then lookup the FromURI for company details	
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN (SELECT TOP 1 Company FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + fu.UserUri LIKE SipAddress)
END AS ChargeToCompany,

--DEPARTMENT TO CHARGE
CASE
	--If the referrer initiates an outbound PSTN call then lookup the ReferredByURI for department details
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways)  AND ru.UserUri IS NOT NULL THEN (SELECT TOP 1 Company FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + ru.UserUri LIKE SipAddress)
	--If the caller initiates an outbound PSTN call then lookup the FromURI for department details	
	WHEN tgw.Gateway IN (select GatewayIP from tempdb.dbo.LyncCallAccountingGateways) THEN (SELECT TOP 1 Department FROM tempdb.dbo.LyncCallAccountingUsers WHERE 'sip:' + fu.UserUri LIKE SipAddress)
END AS ChargeToDepartment

FROM
--LYNC2013/2010
VoipDetails AS vd LEFT OUTER JOIN
    SessionDetails AS sd ON sd.SessionIdTime = vd.SessionIdTime  AND vd.SessionIdSeq = sd.SessionIdSeq LEFT OUTER JOIN
    Phones AS fp ON vd.FromNumberId = fp.PhoneId LEFT OUTER JOIN
    Phones AS cp ON vd.ConnectedNumberId = cp.PhoneId LEFT OUTER JOIN
	Users AS fu ON sd.User1Id = fu.UserId LEFT OUTER JOIN
	Users AS tu ON sd.User2Id = tu.UserId LEFT OUTER JOIN
	Gateways AS fgw ON vd.FromGatewayId = fgw.GatewayId LEFT OUTER JOIN
	Gateways AS tgw ON vd.ToGatewayId = tgw.GatewayId LEFT OUTER JOIN
	MediationServers AS fms ON vd.FromMediationServerId = fms.MediationServerId LEFT OUTER JOIN
	MediationServers AS tms ON vd.ToMediationServerId = tms.MediationServerId LEFT OUTER JOIN
	Phones AS dp ON vd.DisconnectedByPhoneId = dp.PhoneId LEFT OUTER JOIN
	Users AS du ON vd.DisconnectedByURIId = du.UserId LEFT OUTER JOIN
	Users AS ru ON sd.ReferredById = ru.UserId LEFT OUTER JOIN
	dbo.Media AS m ON m.SessionIdTime = sd.SessionIdTime LEFT OUTER JOIN
	dbo.ClientVersions AS fcv ON sd.User1ClientVerId = fcv.VersionId LEFT OUTER JOIN
	dbo.ClientVersions AS tcv ON sd.User2ClientVerId = tcv.VersionId

WHERE 
--CONVERT(datetime, SWITCHOFFSET(CONVERT(datetimeoffset, m.StartTime), DATENAME(TzOffset, SYSDATETIMEOFFSET())))  between '2014-03-01 00:00:00.00' AND '2014-03-31 23:59:59.999'
CONVERT(datetime, SWITCHOFFSET(CONVERT(datetimeoffset, m.StartTime), DATENAME(TzOffset, SYSDATETIMEOFFSET())))  between 'PSvar_StartDate' AND 'PSvar_EndDate'
AND (sd.ResponseCode = 200)
AND fcv.Version NOT LIKE '%txexecutor' AND tcv.Version NOT LIKE '%txexecutor' 
AND fcv.Version NOT LIKE '%synthetic transaction%' AND tcv.Version NOT LIKE '%synthetic transaction%'
--AND fu.UserUri NOT LIKE '%6495571380%'

ORDER BY
m.StartTime DESC